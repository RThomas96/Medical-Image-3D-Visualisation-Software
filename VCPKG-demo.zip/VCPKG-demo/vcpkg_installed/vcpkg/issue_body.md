Package: libsystemd:x64-linux@256.4

**Host Environment**

- Host: x64-linux
- Compiler: GNU 11.4.0
-    vcpkg-tool version: 2024-10-18-e392d7347fe72dff56e7857f7571c22301237ae6
    vcpkg-scripts version: 41626fd77 2024-10-23 (27 hours ago)

**To Reproduce**

`vcpkg install `

**Failure logs**

```
-- Found Python version '3.10.12 at /usr/bin/python3'
-- Using meson: /home/thomas/vcpkg/downloads/tools/meson-1.6.0-ac58a9/meson.py
-- Using cached systemd-systemd-v256.4.tar.gz.
-- Cleaning sources at /home/thomas/vcpkg/buildtrees/libsystemd/src/v256.4-825386a66f.clean. Use --editable to skip cleaning for the packages you specify.
-- Extracting source /home/thomas/vcpkg/downloads/systemd-systemd-v256.4.tar.gz
-- Applying patch disable-warning-nonnull.patch
-- Applying patch only-libsystemd.patch
-- Applying patch pkgconfig.patch
-- Using source at /home/thomas/vcpkg/buildtrees/libsystemd/src/v256.4-825386a66f.clean
-- Configuring x64-linux-dbg
-- Getting CMake variables for x64-linux
CMake Error at scripts/cmake/vcpkg_execute_required_process.cmake:127 (message):
    Command failed: /usr/bin/python3 -I /home/thomas/vcpkg/downloads/tools/meson-1.6.0-ac58a9/meson.py setup -Dmode=release -Dstatic-libsystemd=pic -Dtests=false -Ddns-over-tls=false -Dtranslations=false -Dacl=disabled -Dapparmor=disabled -Daudit=disabled -Dblkid=disabled -Dbpf-framework=disabled -Dbzip2=disabled -Ddbus=disabled -Delfutils=disabled -Dfdisk=disabled -Dgcrypt=disabled -Dglib=disabled -Dgnutls=disabled -Dkmod=disabled -Dlibcurl=disabled -Dlibcryptsetup=disabled -Dlibfido2=disabled -Dlibidn=disabled -Dlibidn2=disabled -Dlibiptc=disabled -Dmicrohttpd=disabled -Dopenssl=disabled -Dp11kit=disabled -Dpam=disabled -Dpcre2=disabled -Dpolkit=disabled -Dpwquality=disabled -Dpasswdqc=disabled -Dseccomp=disabled -Dselinux=disabled -Dtpm2=disabled -Dxenctrl=disabled -Dxkbcommon=disabled -Dzlib=disabled -Dlz4=enabled -Dxz=enabled -Dzstd=enabled --backend ninja --wrap-mode nodownload -Doptimization=plain --native /home/thomas/vcpkg/buildtrees/libsystemd/meson-x64-linux-dbg.log --libdir lib --pkgconfig.relocatable -Ddebug=true --prefix /home/thomas/vcpkg/packages/libsystemd_x64-linux/debug --includedir ../include --pkg-config-path ['/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig','/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig'] -Dcmake_prefix_path=['/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug','/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux'] /home/thomas/vcpkg/buildtrees/libsystemd/src/v256.4-825386a66f.clean
    Working Directory: /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg
    Error code: 1
    See logs for more information:
      /home/thomas/vcpkg/buildtrees/libsystemd/config-x64-linux-dbg-meson-log.txt.log
      /home/thomas/vcpkg/buildtrees/libsystemd/config-x64-linux-dbg-out.log

Call Stack (most recent call first):
  /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/vcpkg-tool-meson/vcpkg_configure_meson.cmake:468 (vcpkg_execute_required_process)
  /home/thomas/.cache/vcpkg/registries/git-trees/03b20e5c1a908db5d38dd3fad3fa074c10e6b04b/portfile.cmake:17 (vcpkg_configure_meson)
  scripts/ports.cmake:192 (include)



```

<details><summary>/home/thomas/vcpkg/buildtrees/libsystemd/config-x64-linux-dbg-out.log</summary>

```
The Meson build system
Version: 1.6.0
Source dir: /home/thomas/vcpkg/buildtrees/libsystemd/src/v256.4-825386a66f.clean
Build dir: /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg
Build type: native build
Project name: systemd
Project version: 256.4
C compiler for the host machine: /usr/bin/cc -fPIC -g (gcc 11.4.0 "cc (Ubuntu 11.4.0-1ubuntu1~22.04) 11.4.0")
C linker for the host machine: /usr/bin/cc -fPIC -g ld.bfd 2.38
Host machine cpu family: x86_64
Host machine cpu: x86_64
Program tools/git-setup.sh found: YES (/home/thomas/vcpkg/buildtrees/libsystemd/src/v256.4-825386a66f.clean/tools/git-setup.sh)
Program tools/meson-build.sh found: YES (/home/thomas/vcpkg/buildtrees/libsystemd/src/v256.4-825386a66f.clean/tools/meson-build.sh)
C++ compiler for the host machine: /usr/bin/c++ -fPIC -g (gcc 11.4.0 "c++ (Ubuntu 11.4.0-1ubuntu1~22.04) 11.4.0")
C++ linker for the host machine: /usr/bin/c++ -fPIC -g ld.bfd 2.38
Compiler for C supports arguments -Wno-missing-field-initializers: YES 
Compiler for C supports arguments -Wno-unused-parameter: YES 
Compiler for C supports arguments -Wno-nonnull-compare: YES 
Compiler for C supports arguments -Warray-bounds: YES 
Compiler for C supports arguments -Warray-bounds=2: YES 
Compiler for C supports arguments -Wdate-time: YES 
Compiler for C supports arguments -Wendif-labels: YES 
Compiler for C supports arguments -Werror=format=2: YES 
Compiler for C supports arguments -Werror=format-signedness: YES 
Compiler for C supports arguments -Werror=implicit-function-declaration: YES 
Compiler for C supports arguments -Werror=implicit-int: YES 
Compiler for C supports arguments -Werror=incompatible-pointer-types: YES 
Compiler for C supports arguments -Werror=int-conversion: YES 
Compiler for C supports arguments -Werror=missing-declarations: YES 
Compiler for C supports arguments -Werror=missing-prototypes: YES 
Compiler for C supports arguments -Werror=overflow: YES 
Compiler for C supports arguments -Werror=override-init: YES 
Compiler for C supports arguments -Werror=return-type: YES 
Compiler for C supports arguments -Werror=shift-count-overflow: YES 
Compiler for C supports arguments -Werror=shift-overflow=2: YES 
Compiler for C supports arguments -Werror=strict-flex-arrays: NO 
Compiler for C supports arguments -Werror=undef: YES 
Compiler for C supports arguments -Wfloat-equal: YES 
Compiler for C supports arguments -Wimplicit-fallthrough=5: YES 
Compiler for C supports arguments -Winit-self: YES 
Compiler for C supports arguments -Wlogical-op: YES 
Compiler for C supports arguments -Wmissing-include-dirs: YES 
Compiler for C supports arguments -Wmissing-noreturn: YES 
Compiler for C supports arguments -Wnested-externs: YES 
Compiler for C supports arguments -Wold-style-definition: YES 
Compiler for C supports arguments -Wpointer-arith: YES 
Compiler for C supports arguments -Wredundant-decls: YES 
Compiler for C supports arguments -Wshadow: YES 
Compiler for C supports arguments -Wstrict-aliasing=2: YES 
Compiler for C supports arguments -Wstrict-prototypes: YES 
Compiler for C supports arguments -Wsuggest-attribute=noreturn: YES 
Compiler for C supports arguments -Wunused-function: YES 
Compiler for C supports arguments -Wwrite-strings: YES 
Compiler for C supports arguments -Wzero-length-bounds: YES 
Compiler for C supports arguments -Wno-error=#warnings: NO 
Compiler for C supports arguments -Wno-string-plus-int: NO 
Compiler for C supports arguments -fdiagnostics-show-option: YES 
Compiler for C supports arguments -fno-common: YES 
Compiler for C supports arguments -fstack-protector: YES 
Compiler for C supports arguments -fstack-protector-strong: YES 
Compiler for C supports arguments -fstrict-flex-arrays: NO 
Compiler for C supports arguments --param=ssp-buffer-size=4: YES 
Compiler for C supports arguments -Wno-maybe-uninitialized: YES 
Compiler for C supports arguments -Wno-unused-result: YES 
Compiler for C supports arguments -ftrivial-auto-var-init=zero: NO 
Compiler for C supports link arguments -fstack-protector: YES 
Compiler for C supports arguments -fno-strict-aliasing: YES 
Compiler for C supports arguments -fstrict-flex-arrays=1: NO 
Compiler for C supports arguments -fvisibility=hidden: YES 
Compiler for C supports link arguments -Wl,--fatal-warnings: YES 
Compiler for C supports link arguments -Wl,-z,now: YES 
Compiler for C supports link arguments -Wl,-z,relro: YES 
Compiler for C supports link arguments -Wl,--warn-common: YES 
Compiler for C supports arguments -Wzero-length-bounds: YES (cached)
Checking if "-Werror=shadow with local shadowing" compiles: YES 
Compiler for C++ supports arguments -Wno-missing-field-initializers: YES 
Compiler for C++ supports arguments -Wno-unused-parameter: YES 
Compiler for C++ supports arguments -Wno-nonnull-compare: YES 
Compiler for C supports arguments -Wstringop-truncation: YES 
Checking for size of "dev_t" : 8 
Checking for size of "ino_t" : 8 
Checking for size of "rlim_t" : 8 
Checking for size of "time_t" : 8 
Checking for size of "typeof(((struct timex *)0)->freq)" : 8 
Computing int of "LONG_MAX" : 9223372036854775807
Checking for size of "char16_t" : 2 
Checking for size of "char32_t" : 4 
Checking for size of "struct mount_attr" : -1 
Checking for size of "struct mount_attr" : 32 
Checking for size of "struct statx" : 256 
Checking for size of "struct dirent64" : 280 
Checking for size of "struct sched_attr" : -1 
Checking for function "secure_getenv" : YES 
Checking for function "__secure_getenv" : NO 
Checking for function "memfd_create" : YES 
Checking for function "gettid" : YES 
Checking for function "fchmodat2" : NO 
Checking for function "pivot_root" : NO 
Checking for function "ioprio_get" : NO 
Checking for function "ioprio_set" : NO 
Checking for function "sched_setattr" : NO 
Checking for function "name_to_handle_at" : YES 
Checking for function "setns" : YES 
Checking for function "renameat2" : YES 
Checking for function "kcmp" : NO 
Checking for function "keyctl" : NO 
Checking for function "copy_file_range" : YES 
Checking for function "bpf" : NO 
Checking for function "statx" : YES 
Checking for function "explicit_bzero" : YES 
Checking for function "reallocarray" : YES 
Checking for function "set_mempolicy" : NO 
Checking for function "get_mempolicy" : NO 
Checking for function "pidfd_send_signal" : NO 
Checking for function "pidfd_open" : NO 
Checking for function "rt_sigqueueinfo" : NO 
Checking for function "rt_tgsigqueueinfo" : NO 
Checking for function "mallinfo" : YES 
Checking for function "mallinfo2" : YES 
Checking for function "execveat" : YES 
Checking for function "close_range" : YES 
Checking for function "epoll_pwait2" : YES 
Checking for function "mount_setattr" : NO 
Checking for function "move_mount" : NO 
Checking for function "open_tree" : NO 
Checking for function "fsopen" : NO 
Checking for function "fsconfig" : NO 
Checking for function "fsmount" : NO 
Checking for function "getdents64" : YES 
Checking for function "pidfd_spawn" : NO 
Checking for function "getrandom" : YES 
Program sh found: YES (/usr/bin/sh)
Program echo found: YES (/usr/bin/echo)
Program sed found: YES (/usr/bin/sed)
Program awk found: YES (/usr/bin/awk)
Program stat found: YES (/usr/bin/stat)
Program ln found: YES (/usr/bin/ln)
Program git found: YES (/usr/bin/git)
Program env found: YES (/usr/bin/env)
Program rsync found: YES (/usr/bin/rsync)
Program diff found: YES (/usr/bin/diff)
Program find found: YES (/usr/bin/find)
Program quotaon /usr/sbin/quotaon /sbin/quotaon found: NO
Program quotacheck /usr/sbin/quotacheck /sbin/quotacheck found: NO
Program kmod found: YES (/usr/bin/kmod)
Program kexec /usr/sbin/kexec /sbin/kexec found: NO
Program sulogin found: YES (/usr/sbin/sulogin)
Program mount found: YES (/usr/bin/mount)
Program umount found: YES (/usr/bin/umount)
Program loadkeys found: YES (/usr/bin/loadkeys)
Program setfont found: YES (/usr/bin/setfont)
Program nologin found: YES (/usr/sbin/nologin)
Program gperf found: YES
Message: gperf len type is size_t
Has header "sys/capability.h" : YES 
Has header "crypt.h" : YES 
Has header "linux/ioprio.h" : YES 
Has header "linux/memfd.h" : YES 
Has header "linux/time_types.h" : YES 
Has header "linux/vm_sockets.h" : YES 
Has header "sys/auxv.h" : YES 
Has header "sys/sdt.h" : NO 
Has header "threads.h" : YES 
Has header "valgrind/memcheck.h" : NO 
Has header "valgrind/valgrind.h" : NO 
../src/v256.4-825386a66f.clean/meson.build:906: WARNING: 
The local group with the GID 65534 does not match the configured group name "nobody" of the nobody group (its name is nogroup).
Your build will result in an group table setup that is incompatible with the local system.
Run-time dependency threads found: YES
Library rt found: YES
Library m found: YES
Library dl found: YES
Found pkg-config: YES (/bin/pkg-config) 0.29.2
Run-time dependency libcrypt found: YES 4.4.36
Run-time dependency libcap found: YES 2.70
Checking if "libatomic" : links: YES 
Checking for function "crypt_ra" with dependency libcrypt: YES 
Checking for function "crypt_preferred_method" with dependency libcrypt: YES 
Checking for function "crypt_gensalt_ra" with dependency libcrypt: YES 
Dependency libbpf skipped: feature bpf-framework disabled
Run-time dependency mount found: YES 2.40.0
Dependency fdisk skipped: feature fdisk disabled
Dependency pwquality skipped: feature pwquality disabled
Dependency passwdqc skipped: feature passwdqc disabled
Dependency libseccomp skipped: feature seccomp disabled
Dependency libselinux skipped: feature selinux disabled
Dependency libapparmor skipped: feature apparmor disabled
Dependency polkit-gobject-1 skipped: feature polkit disabled
Dependency libacl skipped: feature acl disabled
Dependency audit skipped: feature audit disabled
Dependency blkid skipped: feature blkid disabled
Dependency libkmod skipped: feature kmod disabled
Dependency xencontrol skipped: feature xenctrl disabled
Dependency pam skipped: feature pam disabled
Library pam skipped: feature pam disabled
Dependency pam_misc skipped: feature pam disabled
Library pam_misc skipped: feature pam disabled
Dependency libmicrohttpd skipped: feature microhttpd disabled
Dependency libcryptsetup skipped: feature libcryptsetup disabled
Checking for function "crypt_activate_by_token_pin" with dependency libcryptsetup: NO 
Dependency libcurl skipped: feature libcurl disabled
Dependency libidn2 skipped: feature libidn2 disabled
Dependency libidn skipped: feature libidn disabled
Dependency libiptc skipped: feature libiptc disabled
Found CMake: /home/thomas/vcpkg/downloads/tools/cmake-3.30.1-linux/cmake-3.30.1-linux-x86_64/bin/cmake (3.30.1)
Run-time dependency libqrencode found: NO (tried pkgconfig and cmake)
Dependency libgcrypt skipped: feature gcrypt disabled
Dependency gpg-error skipped: feature gcrypt disabled
Library gpg-error skipped: feature gcrypt disabled
Dependency gnutls skipped: feature gnutls disabled
Dependency openssl skipped: feature openssl disabled
Dependency p11-kit-1 skipped: feature p11kit disabled
Dependency libfido2 skipped: feature libfido2 disabled
Dependency tss2-esys tss2-rc tss2-mu tss2-tcti-device skipped: feature tpm2 disabled
Dependency libdw skipped: feature elfutils disabled
Dependency zlib skipped: feature zlib disabled
Dependency bzip2 skipped: feature bzip2 disabled
Library bz2 skipped: feature bzip2 disabled
Run-time dependency liblzma found: YES 5.6.3
Run-time dependency liblz4 found: YES 1.10.0
Run-time dependency libzstd found: YES 1.5.6
Run-time dependency libarchive found: NO (tried pkgconfig and cmake)
Dependency xkbcommon skipped: feature xkbcommon disabled
Dependency libpcre2-8 skipped: feature pcre2 disabled
Dependency glib-2.0 skipped: feature glib disabled
Dependency gobject-2.0 skipped: feature glib disabled
Dependency gio-2.0 skipped: feature glib disabled
Dependency dbus-1 skipped: feature dbus disabled
Message: default-dnssec cannot be set to yes or allow-downgrade openssl and gcrypt are disabled. Setting default-dnssec to no.
Program python3 (jinja2) found: NO

../src/v256.4-825386a66f.clean/meson.build:1725:15: ERROR: python3 is missing modules: jinja2

A full log can be found at /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-logs/meson-log.txt
```
</details>

<details><summary>/home/thomas/vcpkg/buildtrees/libsystemd/config-x64-linux-dbg-meson-log.txt.log</summary>

```
Build started at 2024-10-25T08:20:39.995836
Main binary: /usr/bin/python3
Build Options: -Dmode=release -Dstatic-libsystemd=pic -Dtests=false -Ddns-over-tls=false -Dtranslations=false -Dacl=disabled -Dapparmor=disabled -Daudit=disabled -Dblkid=disabled -Dbpf-framework=disabled -Dbzip2=disabled -Ddbus=disabled -Delfutils=disabled -Dfdisk=disabled -Dgcrypt=disabled -Dglib=disabled -Dgnutls=disabled -Dkmod=disabled -Dlibcurl=disabled -Dlibcryptsetup=disabled -Dlibfido2=disabled -Dlibidn=disabled -Dlibidn2=disabled -Dlibiptc=disabled -Dmicrohttpd=disabled -Dopenssl=disabled -Dp11kit=disabled -Dpam=disabled -Dpcre2=disabled -Dpolkit=disabled -Dpwquality=disabled -Dpasswdqc=disabled -Dseccomp=disabled -Dselinux=disabled -Dtpm2=disabled -Dxenctrl=disabled -Dxkbcommon=disabled -Dzlib=disabled -Dlz4=enabled -Dxz=enabled -Dzstd=enabled -Doptimization=plain -Ddebug=true '-Dcmake_prefix_path=['"'"'/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug'"'"','"'"'/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux'"'"']' -Dprefix=/home/thomas/vcpkg/packages/libsystemd_x64-linux/debug -Dincludedir=../include -Dlibdir=lib -Dbackend=ninja -Dwrap_mode=nodownload -Dpkgconfig.relocatable=True '-Dpkg_config_path=['"'"'/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig'"'"','"'"'/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig'"'"']' --native-file=/home/thomas/vcpkg/buildtrees/libsystemd/meson-x64-linux-dbg.log
Python system: Linux
The Meson build system
Version: 1.6.0
Source dir: /home/thomas/vcpkg/buildtrees/libsystemd/src/v256.4-825386a66f.clean
Build dir: /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg
Build type: native build
Project name: systemd
Project version: 256.4
-----------
Detecting compiler via: `/usr/bin/cc -fPIC -g --version` -> 0
stdout:
cc (Ubuntu 11.4.0-1ubuntu1~22.04) 11.4.0
Copyright (C) 2021 Free Software Foundation, Inc.
This is free software; see the source for copying conditions.  There is NO
warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
-----------
Running command: -cpp -x c -E -dM -
-----
-----------
Detecting linker via: `/usr/bin/cc -fPIC -g -Wl,--version -L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib` -> 0
stdout:
GNU ld (GNU Binutils for Ubuntu) 2.38
Copyright (C) 2022 Free Software Foundation, Inc.
This program is free software; you may redistribute it under the terms of
the GNU General Public License version 3 or (at your option) a later version.
This program has absolutely no warranty.
-----------
stderr:
collect2 version 11.4.0
/usr/bin/ld -plugin /usr/lib/gcc/x86_64-linux-gnu/11/liblto_plugin.so -plugin-opt=/usr/lib/gcc/x86_64-linux-gnu/11/lto-wrapper -plugin-opt=-fresolution=/tmp/ccmSXuXD.res -plugin-opt=-pass-through=-lgcc -plugin-opt=-pass-through=-lgcc_s -plugin-opt=-pass-through=-lc -plugin-opt=-pass-through=-lgcc -plugin-opt=-pass-through=-lgcc_s --build-id --eh-frame-hdr -m elf_x86_64 --hash-style=gnu --as-needed -dynamic-linker /lib64/ld-linux-x86-64.so.2 -pie -z now -z relro /usr/lib/gcc/x86_64-linux-gnu/11/../../../x86_64-linux-gnu/Scrt1.o /usr/lib/gcc/x86_64-linux-gnu/11/../../../x86_64-linux-gnu/crti.o /usr/lib/gcc/x86_64-linux-gnu/11/crtbeginS.o -L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib -L/usr/lib/gcc/x86_64-linux-gnu/11 -L/usr/lib/gcc/x86_64-linux-gnu/11/../../../x86_64-linux-gnu -L/usr/lib/gcc/x86_64-linux-gnu/11/../../../../lib -L/lib/x86_64-linux-gnu -L/lib/../lib -L/usr/lib/x86_64-linux-gnu -L/usr/lib/../lib -L/usr/lib/gcc/x86_64-linux-gnu/11/../../.. --version -lgcc --push-state --as-needed -lgcc_s --pop-state -lc -lgcc --push-state --as-needed -lgcc_s --pop-state /usr/lib/gcc/x86_64-linux-gnu/11/crtendS.o /usr/lib/gcc/x86_64-linux-gnu/11/../../../x86_64-linux-gnu/crtn.o
-----------
Sanity testing C compiler: /usr/bin/cc -fPIC -g
Is cross compiler: False.
Sanity check compiler command line: /usr/bin/cc -fPIC -g sanitycheckc.c -o sanitycheckc.exe -fPIC -g -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include -D_FILE_OFFSET_BITS=64 -L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib
Sanity check compile stdout:

-----
Sanity check compile stderr:

-----
Running test binary command:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/sanitycheckc.exe
C compiler for the host machine: /usr/bin/cc -fPIC -g (gcc 11.4.0 "cc (Ubuntu 11.4.0-1ubuntu1~22.04) 11.4.0")
C linker for the host machine: /usr/bin/cc -fPIC -g ld.bfd 2.38
-----------
Detecting archiver via: `/usr/bin/ar --version` -> 0
stdout:
GNU ar (GNU Binutils for Ubuntu) 2.38
Copyright (C) 2022 Free Software Foundation, Inc.
This program is free software; you may redistribute it under the terms of
the GNU General Public License version 3 or (at your option) any later version.
This program has absolutely no warranty.
-----------
-----------
Detecting compiler via: `/usr/bin/cc -fPIC -g --version` -> 0
stdout:
cc (Ubuntu 11.4.0-1ubuntu1~22.04) 11.4.0
Copyright (C) 2021 Free Software Foundation, Inc.
This is free software; see the source for copying conditions.  There is NO
warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
-----------
Running command: -cpp -x c -E -dM -
-----
-----------
Detecting linker via: `/usr/bin/cc -fPIC -g -Wl,--version` -> 0
stdout:
GNU ld (GNU Binutils for Ubuntu) 2.38
Copyright (C) 2022 Free Software Foundation, Inc.
This program is free software; you may redistribute it under the terms of
the GNU General Public License version 3 or (at your option) a later version.
This program has absolutely no warranty.
-----------
stderr:
collect2 version 11.4.0
/usr/bin/ld -plugin /usr/lib/gcc/x86_64-linux-gnu/11/liblto_plugin.so -plugin-opt=/usr/lib/gcc/x86_64-linux-gnu/11/lto-wrapper -plugin-opt=-fresolution=/tmp/ccIglRDg.res -plugin-opt=-pass-through=-lgcc -plugin-opt=-pass-through=-lgcc_s -plugin-opt=-pass-through=-lc -plugin-opt=-pass-through=-lgcc -plugin-opt=-pass-through=-lgcc_s --build-id --eh-frame-hdr -m elf_x86_64 --hash-style=gnu --as-needed -dynamic-linker /lib64/ld-linux-x86-64.so.2 -pie -z now -z relro /usr/lib/gcc/x86_64-linux-gnu/11/../../../x86_64-linux-gnu/Scrt1.o /usr/lib/gcc/x86_64-linux-gnu/11/../../../x86_64-linux-gnu/crti.o /usr/lib/gcc/x86_64-linux-gnu/11/crtbeginS.o -L/usr/lib/gcc/x86_64-linux-gnu/11 -L/usr/lib/gcc/x86_64-linux-gnu/11/../../../x86_64-linux-gnu -L/usr/lib/gcc/x86_64-linux-gnu/11/../../../../lib -L/lib/x86_64-linux-gnu -L/lib/../lib -L/usr/lib/x86_64-linux-gnu -L/usr/lib/../lib -L/usr/lib/gcc/x86_64-linux-gnu/11/../../.. --version -lgcc --push-state --as-needed -lgcc_s --pop-state -lc -lgcc --push-state --as-needed -lgcc_s --pop-state /usr/lib/gcc/x86_64-linux-gnu/11/crtendS.o /usr/lib/gcc/x86_64-linux-gnu/11/../../../x86_64-linux-gnu/crtn.o
-----------
Sanity testing C compiler: /usr/bin/cc -fPIC -g
Is cross compiler: False.
Sanity check compiler command line: /usr/bin/cc -fPIC -g sanitycheckc.c -o sanitycheckc.exe -D_FILE_OFFSET_BITS=64
Sanity check compile stdout:

-----
Sanity check compile stderr:

-----
Running test binary command:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/sanitycheckc.exe
C compiler for the build machine: /usr/bin/cc -fPIC -g (gcc 11.4.0 "cc (Ubuntu 11.4.0-1ubuntu1~22.04) 11.4.0")
C linker for the build machine: /usr/bin/cc -fPIC -g ld.bfd 2.38
-----------
Detecting archiver via: `/usr/bin/ar --version` -> 0
stdout:
GNU ar (GNU Binutils for Ubuntu) 2.38
Copyright (C) 2022 Free Software Foundation, Inc.
This program is free software; you may redistribute it under the terms of
the GNU General Public License version 3 or (at your option) any later version.
This program has absolutely no warranty.
-----------
Build machine cpu family: x86_64
Build machine cpu: x86_64
Host machine cpu family: x86_64
Host machine cpu: x86_64
Target machine cpu family: x86_64
Target machine cpu: x86_64
Running command: /usr/bin/realpath --relative-to=/home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg /home/thomas/vcpkg/buildtrees/libsystemd/src/v256.4-825386a66f.clean
--- stdout ---
../src/v256.4-825386a66f.clean

--- stderr ---


Program tools/git-setup.sh found: YES (/home/thomas/vcpkg/buildtrees/libsystemd/src/v256.4-825386a66f.clean/tools/git-setup.sh)
Running command: /home/thomas/vcpkg/buildtrees/libsystemd/src/v256.4-825386a66f.clean/tools/git-setup.sh
--- stdout ---

--- stderr ---


Program tools/meson-build.sh found: YES (/home/thomas/vcpkg/buildtrees/libsystemd/src/v256.4-825386a66f.clean/tools/meson-build.sh)
-----------
Detecting compiler via: `/usr/bin/c++ -fPIC -g --version` -> 0
stdout:
c++ (Ubuntu 11.4.0-1ubuntu1~22.04) 11.4.0
Copyright (C) 2021 Free Software Foundation, Inc.
This is free software; see the source for copying conditions.  There is NO
warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
-----------
Running command: -cpp -x c++ -E -dM -
-----
-----------
Detecting linker via: `/usr/bin/c++ -fPIC -g -Wl,--version -L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib` -> 0
stdout:
GNU ld (GNU Binutils for Ubuntu) 2.38
Copyright (C) 2022 Free Software Foundation, Inc.
This program is free software; you may redistribute it under the terms of
the GNU General Public License version 3 or (at your option) a later version.
This program has absolutely no warranty.
-----------
stderr:
collect2 version 11.4.0
/usr/bin/ld -plugin /usr/lib/gcc/x86_64-linux-gnu/11/liblto_plugin.so -plugin-opt=/usr/lib/gcc/x86_64-linux-gnu/11/lto-wrapper -plugin-opt=-fresolution=/tmp/ccp1B3Gf.res -plugin-opt=-pass-through=-lgcc_s -plugin-opt=-pass-through=-lgcc -plugin-opt=-pass-through=-lc -plugin-opt=-pass-through=-lgcc_s -plugin-opt=-pass-through=-lgcc --build-id --eh-frame-hdr -m elf_x86_64 --hash-style=gnu --as-needed -dynamic-linker /lib64/ld-linux-x86-64.so.2 -pie -z now -z relro /usr/lib/gcc/x86_64-linux-gnu/11/../../../x86_64-linux-gnu/Scrt1.o /usr/lib/gcc/x86_64-linux-gnu/11/../../../x86_64-linux-gnu/crti.o /usr/lib/gcc/x86_64-linux-gnu/11/crtbeginS.o -L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib -L/usr/lib/gcc/x86_64-linux-gnu/11 -L/usr/lib/gcc/x86_64-linux-gnu/11/../../../x86_64-linux-gnu -L/usr/lib/gcc/x86_64-linux-gnu/11/../../../../lib -L/lib/x86_64-linux-gnu -L/lib/../lib -L/usr/lib/x86_64-linux-gnu -L/usr/lib/../lib -L/usr/lib/gcc/x86_64-linux-gnu/11/../../.. --version -lstdc++ -lm -lgcc_s -lgcc -lc -lgcc_s -lgcc /usr/lib/gcc/x86_64-linux-gnu/11/crtendS.o /usr/lib/gcc/x86_64-linux-gnu/11/../../../x86_64-linux-gnu/crtn.o
-----------
Sanity testing C++ compiler: /usr/bin/c++ -fPIC -g
Is cross compiler: False.
Sanity check compiler command line: /usr/bin/c++ -fPIC -g sanitycheckcpp.cc -o sanitycheckcpp.exe -fPIC -g -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include -D_FILE_OFFSET_BITS=64 -L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib
Sanity check compile stdout:

-----
Sanity check compile stderr:

-----
Running test binary command:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/sanitycheckcpp.exe
C++ compiler for the host machine: /usr/bin/c++ -fPIC -g (gcc 11.4.0 "c++ (Ubuntu 11.4.0-1ubuntu1~22.04) 11.4.0")
C++ linker for the host machine: /usr/bin/c++ -fPIC -g ld.bfd 2.38
Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmp843tr2wz
Code:
extern int i;
int i;

-----------
Command line: `/usr/bin/cc -fPIC -g -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmp843tr2wz/testfile.c -o /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmp843tr2wz/output.obj -c -fPIC -g -D_FILE_OFFSET_BITS=64 -O0 -Wmissing-field-initializers -Wno-missing-field-initializers` -> 0
Compiler for C supports arguments -Wno-missing-field-initializers: YES 
Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpw8kxzvei
Code:
extern int i;
int i;

-----------
Command line: `/usr/bin/cc -fPIC -g -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpw8kxzvei/testfile.c -o /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpw8kxzvei/output.obj -c -fPIC -g -D_FILE_OFFSET_BITS=64 -O0 -Wunused-parameter -Wno-unused-parameter` -> 0
Compiler for C supports arguments -Wno-unused-parameter: YES 
Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpcqaqo4mk
Code:
extern int i;
int i;

-----------
Command line: `/usr/bin/cc -fPIC -g -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpcqaqo4mk/testfile.c -o /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpcqaqo4mk/output.obj -c -fPIC -g -D_FILE_OFFSET_BITS=64 -O0 -Wnonnull-compare -Wno-nonnull-compare` -> 0
Compiler for C supports arguments -Wno-nonnull-compare: YES 
Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpzowx3h9r
Code:
extern int i;
int i;

-----------
Command line: `/usr/bin/cc -fPIC -g -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpzowx3h9r/testfile.c -o /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpzowx3h9r/output.obj -c -fPIC -g -D_FILE_OFFSET_BITS=64 -O0 -Warray-bounds` -> 0
Compiler for C supports arguments -Warray-bounds: YES 
Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpx3z451cv
Code:
extern int i;
int i;

-----------
Command line: `/usr/bin/cc -fPIC -g -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpx3z451cv/testfile.c -o /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpx3z451cv/output.obj -c -fPIC -g -D_FILE_OFFSET_BITS=64 -O0 -Warray-bounds=2` -> 0
Compiler for C supports arguments -Warray-bounds=2: YES 
Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpc_0ixz93
Code:
extern int i;
int i;

-----------
Command line: `/usr/bin/cc -fPIC -g -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpc_0ixz93/testfile.c -o /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpc_0ixz93/output.obj -c -fPIC -g -D_FILE_OFFSET_BITS=64 -O0 -Wdate-time` -> 0
Compiler for C supports arguments -Wdate-time: YES 
Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpt_h9yl1f
Code:
extern int i;
int i;

-----------
Command line: `/usr/bin/cc -fPIC -g -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpt_h9yl1f/testfile.c -o /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpt_h9yl1f/output.obj -c -fPIC -g -D_FILE_OFFSET_BITS=64 -O0 -Wendif-labels` -> 0
Compiler for C supports arguments -Wendif-labels: YES 
Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmp207a8rud
Code:
extern int i;
int i;

-----------
Command line: `/usr/bin/cc -fPIC -g -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmp207a8rud/testfile.c -o /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmp207a8rud/output.obj -c -fPIC -g -D_FILE_OFFSET_BITS=64 -O0 -Werror=format=2` -> 0
Compiler for C supports arguments -Werror=format=2: YES 
Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmph5db68kg
Code:
extern int i;
int i;

-----------
Command line: `/usr/bin/cc -fPIC -g -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmph5db68kg/testfile.c -o /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmph5db68kg/output.obj -c -fPIC -g -D_FILE_OFFSET_BITS=64 -O0 -Werror=format-signedness` -> 0
Compiler for C supports arguments -Werror=format-signedness: YES 
Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpbvrn4o91
Code:
extern int i;
int i;

-----------
...
Skipped 2845 lines
...
    4 |           #error "Header 'sys/sdt.h' could not be found"
      |            ^~~~~
-----------
Has header "sys/sdt.h" : NO 
Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmptmrrsp7k
Code:

        #ifdef __has_include
         #if !__has_include("threads.h")
          #error "Header 'threads.h' could not be found"
         #endif
        #else
         #include <threads.h>
        #endif
-----------
Command line: `/usr/bin/cc -fPIC -g -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmptmrrsp7k/testfile.c -E -P -fPIC -g -D_FILE_OFFSET_BITS=64 -P -O0 -std=gnu11` -> 0
Has header "threads.h" : YES 
Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpdzfziiah
Code:

        #ifdef __has_include
         #if !__has_include("valgrind/memcheck.h")
          #error "Header 'valgrind/memcheck.h' could not be found"
         #endif
        #else
         #include <valgrind/memcheck.h>
        #endif
-----------
Command line: `/usr/bin/cc -fPIC -g -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpdzfziiah/testfile.c -E -P -fPIC -g -D_FILE_OFFSET_BITS=64 -P -O0 -std=gnu11` -> 1
stderr:
/home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpdzfziiah/testfile.c:4:12: error: #error "Header 'valgrind/memcheck.h' could not be found"
    4 |           #error "Header 'valgrind/memcheck.h' could not be found"
      |            ^~~~~
-----------
Has header "valgrind/memcheck.h" : NO 
Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmp4kws9x9j
Code:

        #ifdef __has_include
         #if !__has_include("valgrind/valgrind.h")
          #error "Header 'valgrind/valgrind.h' could not be found"
         #endif
        #else
         #include <valgrind/valgrind.h>
        #endif
-----------
Command line: `/usr/bin/cc -fPIC -g -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmp4kws9x9j/testfile.c -E -P -fPIC -g -D_FILE_OFFSET_BITS=64 -P -O0 -std=gnu11` -> 1
stderr:
/home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmp4kws9x9j/testfile.c:4:12: error: #error "Header 'valgrind/valgrind.h' could not be found"
    4 |           #error "Header 'valgrind/valgrind.h' could not be found"
      |            ^~~~~
-----------
Has header "valgrind/valgrind.h" : NO 
Running command: /usr/bin/sh -c 'echo "$SOURCE_DATE_EPOCH"'
--- stdout ---


--- stderr ---


Running command: /usr/bin/stat -c %Y /home/thomas/vcpkg/buildtrees/libsystemd/src/v256.4-825386a66f.clean/NEWS
--- stdout ---
1721825379

--- stderr ---


Running command: /usr/bin/awk '/^\s*SYS_UID_MIN\s+/ { uid=$2 } END { print uid }' /etc/login.defs
--- stdout ---


--- stderr ---


Running command: /usr/bin/awk '/^\s*SYS_UID_MAX\s+/ { uid=$2 } END { print uid }' /etc/login.defs
--- stdout ---


--- stderr ---


Running command: /usr/bin/awk '/^\s*SYS_GID_MIN\s+/ { uid=$2 } END { print uid }' /etc/login.defs
--- stdout ---


--- stderr ---


Running command: /usr/bin/awk '/^\s*SYS_GID_MAX\s+/ { uid=$2 } END { print uid }' /etc/login.defs
--- stdout ---


--- stderr ---


Running command: /usr/bin/getent passwd 65534
--- stdout ---
nobody:x:65534:65534:nobody:/nonexistent:/usr/sbin/nologin

--- stderr ---


Running command: /usr/bin/id -u nobody
--- stdout ---
65534

--- stderr ---


Running command: /usr/bin/getent group 65534
--- stdout ---
nogroup:x:65534:

--- stderr ---


../src/v256.4-825386a66f.clean/meson.build:906: WARNING: 
The local group with the GID 65534 does not match the configured group name "nobody" of the nobody group (its name is nogroup).
Your build will result in an group table setup that is incompatible with the local system.
Running command: /usr/bin/id -g nobody
--- stdout ---
65534

--- stderr ---


Run-time dependency threads found: YES
Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmppa5f9kqu
Code:
int main(void) { return 0; }

-----------
Command line: `/usr/bin/cc -fPIC -g -L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmppa5f9kqu/testfile.c -o /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmppa5f9kqu/output.exe -fPIC -g -D_FILE_OFFSET_BITS=64 -O0 -lrt -Wl,--allow-shlib-undefined` -> 0
Library rt found: YES
Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmp8amnb7e6
Code:
int main(void) { return 0; }

-----------
Command line: `/usr/bin/cc -fPIC -g -L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmp8amnb7e6/testfile.c -o /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmp8amnb7e6/output.exe -fPIC -g -D_FILE_OFFSET_BITS=64 -O0 -lm -Wl,--allow-shlib-undefined` -> 0
Library m found: YES
Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpkzhyo6y2
Code:
int main(void) { return 0; }

-----------
Command line: `/usr/bin/cc -fPIC -g -L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpkzhyo6y2/testfile.c -o /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpkzhyo6y2/output.exe -fPIC -g -D_FILE_OFFSET_BITS=64 -O0 -ldl -Wl,--allow-shlib-undefined` -> 0
Library dl found: YES
Pkg-config binary for host machine specified from cross file, native file, or env var as ['/bin/pkg-config']
Found pkg-config: YES (/bin/pkg-config) 0.29.2
Determining dependency 'libcrypt' with pkg-config executable '/bin/pkg-config'
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --modversion libcrypt` -> 0
stdout:
4.4.36
-----------
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --cflags libcrypt` -> 0
stdout:
-I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../../include
-----------
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_ALLOW_SYSTEM_LIBS]: 1
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --libs libcrypt` -> 0
stdout:
-L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../lib -lcrypt
-----------
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --libs libcrypt` -> 0
stdout:
-L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../lib -lcrypt
-----------
Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpcm1r62c9
Code:

        #include<stddef.h>
        #include<stdio.h>
        int main(void) {
            printf("%ld\n", (long)(sizeof(void *)));
            return 0;
        }
-----------
Command line: `/usr/bin/c++ -fPIC -g -L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpcm1r62c9/testfile.cpp -o /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpcm1r62c9/output.exe -fPIC -g -D_FILE_OFFSET_BITS=64 -O0 -fpermissive` -> 0
Program stdout:

8

Program stderr:


Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmp0mh6zu14
Code:

-----------
Command line: `/usr/bin/c++ -fPIC -g -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmp0mh6zu14/testfile.cpp -o /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmp0mh6zu14/output.obj -c -fPIC -g -D_FILE_OFFSET_BITS=64 -O0 -fpermissive --print-search-dirs` -> 0
stdout:
install: /usr/lib/gcc/x86_64-linux-gnu/11/
programs: =/usr/lib/gcc/x86_64-linux-gnu/11/:/usr/lib/gcc/x86_64-linux-gnu/11/:/usr/lib/gcc/x86_64-linux-gnu/:/usr/lib/gcc/x86_64-linux-gnu/11/:/usr/lib/gcc/x86_64-linux-gnu/:/usr/lib/gcc/x86_64-linux-gnu/11/../../../../x86_64-linux-gnu/bin/x86_64-linux-gnu/11/:/usr/lib/gcc/x86_64-linux-gnu/11/../../../../x86_64-linux-gnu/bin/x86_64-linux-gnu/:/usr/lib/gcc/x86_64-linux-gnu/11/../../../../x86_64-linux-gnu/bin/
libraries: =/usr/lib/gcc/x86_64-linux-gnu/11/:/usr/lib/gcc/x86_64-linux-gnu/11/../../../../x86_64-linux-gnu/lib/x86_64-linux-gnu/11/:/usr/lib/gcc/x86_64-linux-gnu/11/../../../../x86_64-linux-gnu/lib/x86_64-linux-gnu/:/usr/lib/gcc/x86_64-linux-gnu/11/../../../../x86_64-linux-gnu/lib/../lib/:/usr/lib/gcc/x86_64-linux-gnu/11/../../../x86_64-linux-gnu/11/:/usr/lib/gcc/x86_64-linux-gnu/11/../../../x86_64-linux-gnu/:/usr/lib/gcc/x86_64-linux-gnu/11/../../../../lib/:/lib/x86_64-linux-gnu/11/:/lib/x86_64-linux-gnu/:/lib/../lib/:/usr/lib/x86_64-linux-gnu/11/:/usr/lib/x86_64-linux-gnu/:/usr/lib/../lib/:/usr/lib/gcc/x86_64-linux-gnu/11/../../../../x86_64-linux-gnu/lib/:/usr/lib/gcc/x86_64-linux-gnu/11/../../../:/lib/:/usr/lib/
-----------
Run-time dependency libcrypt found: YES 4.4.36
Determining dependency 'libcap' with pkg-config executable '/bin/pkg-config'
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --modversion libcap` -> 0
stdout:
2.70
-----------
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --cflags libcap` -> 0
stdout:
-I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../../include
-----------
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_ALLOW_SYSTEM_LIBS]: 1
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --libs libcap` -> 0
stdout:
-L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../lib -lcap
-----------
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --libs libcap` -> 0
stdout:
-L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../lib -lcap
-----------
Run-time dependency libcap found: YES 2.70
Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpdss79ou9
Code:
int main(int argc, char **argv) { return 0; }
-----------
Command line: `/usr/bin/cc -fPIC -g -L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpdss79ou9/testfile.c -o /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpdss79ou9/output.exe -fPIC -g -D_FILE_OFFSET_BITS=64 -O0 -std=gnu11 -latomic` -> 0
Checking if "libatomic" : links: YES 
Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmp1oqastlx
Code:
#include <crypt.h>
#include <limits.h>

        #if defined __stub_crypt_ra || defined __stub___crypt_ra
        fail fail fail this function is not going to work
        #endif
        
int main(void) {
            void *a = (void*) &crypt_ra;
            long long b = (long long) a;
            return (int) b;
        }
-----------
Command line: `/usr/bin/cc -fPIC -g -L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../../include /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmp1oqastlx/testfile.c -o /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmp1oqastlx/output.exe -fPIC -g -D_FILE_OFFSET_BITS=64 -O0 -std=gnu11 -D_GNU_SOURCE /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../lib/libcrypt.a` -> 0
Checking for function "crypt_ra" with dependency libcrypt: YES 
Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpxzshlpsv
Code:
#include <crypt.h>
#include <limits.h>

        #if defined __stub_crypt_preferred_method || defined __stub___crypt_preferred_method
        fail fail fail this function is not going to work
        #endif
        
int main(void) {
            void *a = (void*) &crypt_preferred_method;
            long long b = (long long) a;
            return (int) b;
        }
-----------
Command line: `/usr/bin/cc -fPIC -g -L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../../include /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpxzshlpsv/testfile.c -o /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpxzshlpsv/output.exe -fPIC -g -D_FILE_OFFSET_BITS=64 -O0 -std=gnu11 -D_GNU_SOURCE /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../lib/libcrypt.a` -> 0
Checking for function "crypt_preferred_method" with dependency libcrypt: YES 
Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpslylj_bo
Code:
#include <crypt.h>
#include <limits.h>

        #if defined __stub_crypt_gensalt_ra || defined __stub___crypt_gensalt_ra
        fail fail fail this function is not going to work
        #endif
        
int main(void) {
            void *a = (void*) &crypt_gensalt_ra;
            long long b = (long long) a;
            return (int) b;
        }
-----------
Command line: `/usr/bin/cc -fPIC -g -L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../../include /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpslylj_bo/testfile.c -o /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpslylj_bo/output.exe -fPIC -g -D_FILE_OFFSET_BITS=64 -O0 -std=gnu11 -D_GNU_SOURCE /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../lib/libcrypt.a` -> 0
Checking for function "crypt_gensalt_ra" with dependency libcrypt: YES 
Dependency libbpf skipped: feature bpf-framework disabled
Determining dependency 'mount' with pkg-config executable '/bin/pkg-config'
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --modversion mount` -> 0
stdout:
2.40.0
-----------
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --cflags mount` -> 0
stdout:
-I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../../include/libmount -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../../include/blkid
-----------
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_ALLOW_SYSTEM_LIBS]: 1
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --libs mount` -> 0
stdout:
-L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../lib -lmount -lblkid
-----------
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --libs mount` -> 0
stdout:
-L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../lib -lmount -lblkid
-----------
Run-time dependency mount found: YES 2.40.0
Dependency fdisk skipped: feature fdisk disabled
Dependency pwquality skipped: feature pwquality disabled
Dependency passwdqc skipped: feature passwdqc disabled
Dependency libseccomp skipped: feature seccomp disabled
Dependency libselinux skipped: feature selinux disabled
Dependency libapparmor skipped: feature apparmor disabled
Dependency polkit-gobject-1 skipped: feature polkit disabled
Dependency libacl skipped: feature acl disabled
Dependency audit skipped: feature audit disabled
Dependency blkid skipped: feature blkid disabled
Dependency libkmod skipped: feature kmod disabled
Dependency xencontrol skipped: feature xenctrl disabled
Dependency pam skipped: feature pam disabled
Library pam skipped: feature pam disabled
Dependency pam_misc skipped: feature pam disabled
Library pam_misc skipped: feature pam disabled
Dependency libmicrohttpd skipped: feature microhttpd disabled
Dependency libcryptsetup skipped: feature libcryptsetup disabled
Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpa9b6c6fi
Code:
#include <libcryptsetup.h>
#include <limits.h>

        #if defined __stub_crypt_activate_by_token_pin || defined __stub___crypt_activate_by_token_pin
        fail fail fail this function is not going to work
        #endif
        
int main(void) {
            void *a = (void*) &crypt_activate_by_token_pin;
            long long b = (long long) a;
            return (int) b;
        }
-----------
Command line: `/usr/bin/cc -fPIC -g -L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpa9b6c6fi/testfile.c -o /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpa9b6c6fi/output.exe -fPIC -g -D_FILE_OFFSET_BITS=64 -O0 -std=gnu11` -> 1
stderr:
/home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpa9b6c6fi/testfile.c:1:10: fatal error: libcryptsetup.h: No such file or directory
    1 | #include <libcryptsetup.h>
      |          ^~~~~~~~~~~~~~~~~
compilation terminated.
-----------
Running compile:
Working directory:  /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpxwwarawy
Code:
#include <libcryptsetup.h>
        int main(void) {

        /* With some toolchains (MSYS2/mingw for example) the compiler
         * provides various builtins which are not really implemented and
         * fall back to the stdlib where they aren't provided and fail at
         * build/link time. In case the user provides a header, including
         * the header didn't lead to the function being defined, and the
         * function we are checking isn't a builtin itself we assume the
         * builtin is not functional and we just error out. */
        #if !0 && !defined(crypt_activate_by_token_pin) && !0
            #error "No definition for __builtin_crypt_activate_by_token_pin found in the prefix"
        #endif

        #ifdef __has_builtin
            #if !__has_builtin(__builtin_crypt_activate_by_token_pin)
                #error "__builtin_crypt_activate_by_token_pin not found"
            #endif
        #elif ! defined(crypt_activate_by_token_pin)
            __builtin_crypt_activate_by_token_pin;
        #endif
        return 0;
        }
-----------
Command line: `/usr/bin/cc -fPIC -g -L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/include /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpxwwarawy/testfile.c -o /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpxwwarawy/output.exe -fPIC -g -D_FILE_OFFSET_BITS=64 -O0 -std=gnu11` -> 1
stderr:
/home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/tmpxwwarawy/testfile.c:1:10: fatal error: libcryptsetup.h: No such file or directory
    1 | #include <libcryptsetup.h>
      |          ^~~~~~~~~~~~~~~~~
compilation terminated.
-----------
Checking for function "crypt_activate_by_token_pin" with dependency libcryptsetup: NO 
Dependency libcurl skipped: feature libcurl disabled
Dependency libidn2 skipped: feature libidn2 disabled
Dependency libidn skipped: feature libidn disabled
Dependency libiptc skipped: feature libiptc disabled
Determining dependency 'libqrencode' with pkg-config executable '/bin/pkg-config'
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --modversion libqrencode` -> 1
stderr:
Package libqrencode was not found in the pkg-config search path.
Perhaps you should add the directory containing `libqrencode.pc'
to the PKG_CONFIG_PATH environment variable
No package 'libqrencode' found
-----------
CMake binary for host machine is not cached
CMake binary for host machine specified from cross file, native file, or env var as ['/home/thomas/vcpkg/downloads/tools/cmake-3.30.1-linux/cmake-3.30.1-linux-x86_64/bin/cmake']
Found CMake: /home/thomas/vcpkg/downloads/tools/cmake-3.30.1-linux/cmake-3.30.1-linux-x86_64/bin/cmake (3.30.1)
Extracting basic cmake information
CMake Toolchain: Calling CMake once to generate the compiler state
Calling CMake (['/home/thomas/vcpkg/downloads/tools/cmake-3.30.1-linux/cmake-3.30.1-linux-x86_64/bin/cmake']) in /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/__CMake_compiler_info__ with:
  - "--trace-expand"
  - "--trace-format=json-v1"
  - "--no-warn-unused-cli"
  - "--trace-redirect=cmake_trace.txt"
  - "-G"
  - "Ninja"
  - "-DCMAKE_TOOLCHAIN_FILE=/home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/__CMake_compiler_info__/CMakeMesonTempToolchainFile.cmake"
  - "."
  - "-DCMAKE_PREFIX_PATH=/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug;/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux"
CMake trace warning: add_executable() non imported executables are not supported
CMake TRACE: /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/__CMake_compiler_info__/CMakeFiles/CMakeScratch/TryCompile-SlLqpo/CMakeLists.txt:22 add_executable(['cmTC_e873d'])
CMake trace warning: target_link_libraries() TARGET cmTC_e873d not found
CMake TRACE: /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/__CMake_compiler_info__/CMakeFiles/CMakeScratch/TryCompile-SlLqpo/CMakeLists.txt:28 target_link_libraries(['cmTC_e873d', ''])
CMake trace warning: add_executable() non imported executables are not supported
CMake TRACE: /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/__CMake_compiler_info__/CMakeFiles/CMakeScratch/TryCompile-KzX65i/CMakeLists.txt:22 add_executable(['cmTC_caec6'])
CMake trace warning: target_link_libraries() TARGET cmTC_caec6 not found
CMake TRACE: /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/__CMake_compiler_info__/CMakeFiles/CMakeScratch/TryCompile-KzX65i/CMakeLists.txt:28 target_link_libraries(['cmTC_caec6', ''])
Try CMake generator: auto
Calling CMake (['/home/thomas/vcpkg/downloads/tools/cmake-3.30.1-linux/cmake-3.30.1-linux-x86_64/bin/cmake']) in /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/cmake_libqrencode with:
  - "--trace-expand"
  - "--trace-format=json-v1"
  - "--no-warn-unused-cli"
  - "--trace-redirect=cmake_trace.txt"
  - "-DCMAKE_TOOLCHAIN_FILE=/home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/cmake_libqrencode/CMakeMesonToolchainFile.cmake"
  - "."
  - "-DCMAKE_PREFIX_PATH=/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug;/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux"
  -- Module search paths:    ['/', '/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux', '/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug', '/home/thomas/vcpkg/downloads/tools/cmake-3.30.1-linux/cmake-3.30.1-linux-x86_64', '/opt', '/usr', '/usr/local']
  -- CMake root:             /home/thomas/vcpkg/downloads/tools/cmake-3.30.1-linux/cmake-3.30.1-linux-x86_64/share/cmake-3.30
  -- CMake architectures:    ['x86_64-linux-gnu']
  -- CMake lib search paths: ['lib', 'lib32', 'lib64', 'libx32', 'share', '', 'lib/x86_64-linux-gnu']
Preliminary CMake check failed. Aborting.
Run-time dependency libqrencode found: NO (tried pkgconfig and cmake)
Dependency libgcrypt skipped: feature gcrypt disabled
Dependency gpg-error skipped: feature gcrypt disabled
Library gpg-error skipped: feature gcrypt disabled
Dependency gnutls skipped: feature gnutls disabled
Dependency openssl skipped: feature openssl disabled
Dependency p11-kit-1 skipped: feature p11kit disabled
Dependency libfido2 skipped: feature libfido2 disabled
Dependency tss2-esys tss2-rc tss2-mu tss2-tcti-device skipped: feature tpm2 disabled
Dependency libdw skipped: feature elfutils disabled
Dependency zlib skipped: feature zlib disabled
Dependency bzip2 skipped: feature bzip2 disabled
Library bz2 skipped: feature bzip2 disabled
Determining dependency 'liblzma' with pkg-config executable '/bin/pkg-config'
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --modversion liblzma` -> 0
stdout:
5.6.3
-----------
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --cflags liblzma` -> 0
stdout:
-DLZMA_API_STATIC -I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../../include
-----------
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_ALLOW_SYSTEM_LIBS]: 1
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --libs liblzma` -> 0
stdout:
-L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../lib -llzma -pthread
-----------
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --libs liblzma` -> 0
stdout:
-L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../lib -llzma -pthread
-----------
Run-time dependency liblzma found: YES 5.6.3
Determining dependency 'liblz4' with pkg-config executable '/bin/pkg-config'
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --modversion liblz4` -> 0
stdout:
1.10.0
-----------
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --cflags liblz4` -> 0
stdout:
-I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../../include
-----------
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_ALLOW_SYSTEM_LIBS]: 1
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --libs liblz4` -> 0
stdout:
-L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../lib -llz4d
-----------
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --libs liblz4` -> 0
stdout:
-L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../lib -llz4d
-----------
Run-time dependency liblz4 found: YES 1.10.0
Determining dependency 'libzstd' with pkg-config executable '/bin/pkg-config'
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --modversion libzstd` -> 0
stdout:
1.5.6
-----------
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --cflags libzstd` -> 0
stdout:
-I/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../../include
-----------
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_ALLOW_SYSTEM_LIBS]: 1
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --libs libzstd` -> 0
stdout:
-L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../lib -lzstd
-----------
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --libs libzstd` -> 0
stdout:
-L/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig/../../lib -lzstd
-----------
Run-time dependency libzstd found: YES 1.5.6
Determining dependency 'libarchive' with pkg-config executable '/bin/pkg-config'
env[PKG_CONFIG]: /bin/pkg-config
env[PKG_CONFIG_PATH]: /home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug/lib/pkgconfig:/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/share/pkgconfig
-----------
Called: `/bin/pkg-config --modversion libarchive` -> 1
stderr:
Package libarchive was not found in the pkg-config search path.
Perhaps you should add the directory containing `libarchive.pc'
to the PKG_CONFIG_PATH environment variable
No package 'libarchive' found
-----------
CMake binary for host machine is cached.

Determining dependency 'libarchive' with CMake executable '/home/thomas/vcpkg/downloads/tools/cmake-3.30.1-linux/cmake-3.30.1-linux-x86_64/bin/cmake'
Try CMake generator: auto
Calling CMake (['/home/thomas/vcpkg/downloads/tools/cmake-3.30.1-linux/cmake-3.30.1-linux-x86_64/bin/cmake']) in /home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/cmake_libarchive with:
  - "-DNAME=libarchive"
  - "-DARCHS=x86_64-linux-gnu"
  - "-DVERSION="
  - "-DCOMPS="
  - "-DSTATIC=OFF"
  - "--trace-expand"
  - "--trace-format=json-v1"
  - "--no-warn-unused-cli"
  - "--trace-redirect=cmake_trace.txt"
  - "-DCMAKE_TOOLCHAIN_FILE=/home/thomas/vcpkg/buildtrees/libsystemd/x64-linux-dbg/meson-private/cmake_libarchive/CMakeMesonToolchainFile.cmake"
  - "."
  - "-DCMAKE_PREFIX_PATH=/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux/debug;/home/thomas/VCPKG-demo/vcpkg_installed/x64-linux"
Run-time dependency libarchive found: NO (tried pkgconfig and cmake)
Dependency xkbcommon skipped: feature xkbcommon disabled
Dependency libpcre2-8 skipped: feature pcre2 disabled
Dependency glib-2.0 skipped: feature glib disabled
Dependency gobject-2.0 skipped: feature glib disabled
Dependency gio-2.0 skipped: feature glib disabled
Dependency dbus-1 skipped: feature dbus disabled
Message: default-dnssec cannot be set to yes or allow-downgrade openssl and gcrypt are disabled. Setting default-dnssec to no.
Program python3 (jinja2) found: NO

../src/v256.4-825386a66f.clean/meson.build:1725:15: ERROR: python3 is missing modules: jinja2
```
</details>

**Additional context**

<details><summary>vcpkg.json</summary>

```
{
  "dependencies": [
    "glm",
    "tiff",
    "tinytiff",
    "qt5"
  ]
}

```
</details>
