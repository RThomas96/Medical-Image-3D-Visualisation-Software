cd build
cmake --preset=default ..
ninja
./VCPKG-demo
cd ..
