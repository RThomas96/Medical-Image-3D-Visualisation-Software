
#include "glm_demo.hpp"
#include <iostream>

#include <tinytiffreader.h>
#include <tinytiffwriter.h>
#include <tiff.h>
#include <tiffio.h>

#include <vector>

struct TIFFReaderLibtiff {

    TIFF* tif;
    int openedImage;
    std::vector<std::string> filenames;

    TIFFReaderLibtiff(const std::vector<std::string>& filename);

    glm::vec3 getImageResolution() const;
    glm::vec3 getVoxelSize() const;

    //! @brief Get how many values are contained in a single row of the image
    tsize_t getScanLineSize() const;

    int readScanline(tdata_t buf, uint32 row) const;

    //! @brief The TIFFReader class can handle multiple tiff images, this function set which image has to be read.
    void openImage(int imageIdx);

    //! @brief A single tiff image file can contain an entire stack of images, this function set which image has to be read in the current tiff image.
    void setImageToRead(int sliceIdx);

    void closeImage();
};

enum class ImageFormat {
    TIFF,
    OME_TIFF,
    DIM_IMA
};

int main(int argc, char ** argv)
{
    float translate = 1;
    glm::vec2 rotate(2., 2.);
    glm::mat4 camera = demo_glm::camera(translate, rotate);

    TIFF* tif;
    tif = TIFFOpen("hello.tiff", "r");

    std::cout << "============= Start program =============" << std::endl;
    std::cout << "Success" << std::endl;
    std::cout << "=========================================" << std::endl;

}
